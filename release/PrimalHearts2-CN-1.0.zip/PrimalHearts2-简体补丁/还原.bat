@echo off
chcp 936 >nul
setlocal
set "PACK=%~dp0"
pushd "%PACK%.."
set "GAME=%CD%"
popd

if exist "%GAME%\primhearts2.orig.exe" (
    copy /y "%GAME%\primhearts2.orig.exe" "%GAME%\primhearts2.exe" >nul
    del "%GAME%\primhearts2.orig.exe"
    echo [���] �������ѻ�ԭ
)
if exist "%GAME%\script.noa.bak" (
    copy /y "%GAME%\script.noa.bak" "%GAME%\script.noa" >nul
    echo [���] script.noa �ѻ�ԭ
)
pause
